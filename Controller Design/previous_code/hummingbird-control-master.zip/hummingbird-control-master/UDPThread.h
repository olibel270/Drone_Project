#include "Globals.h"

#ifndef UDPTHREAD_H
#define UDPTHREAD_H
//Function is used in thread, creates a UDP Server Thread for xyz input data
void xyzUDPserver(void *dummy);


#endif