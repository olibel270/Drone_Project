#include "Globals.h"
float g_roll_cmd = 0.0;
float g_pitch_cmd = 0.0;
float g_yaw_cmd = 0.0;
float g_thrust_cmd = 0.0;
bool g_new_data = false;

float g_input_x = 0.0;
float g_input_y = 0.0;
float g_input_z = 0.0;

bool g_input_new_data = false;