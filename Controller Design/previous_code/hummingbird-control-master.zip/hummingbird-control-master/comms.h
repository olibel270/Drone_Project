#include "Globals.h"

#ifndef COMMS_H
#define COMMS_H
//Function is used in thread, creates a UDP client to interface with the Astec ACI
void UDPClient(void *dummy);



#endif